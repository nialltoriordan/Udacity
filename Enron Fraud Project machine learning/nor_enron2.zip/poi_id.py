#!/usr/bin/python
'''
I'm going to use the convention that anything commented like this are comments that I make.
'''
import sys
import pickle
sys.path.append("../tools/")
from time import time
from pprint import pprint
import matplotlib.pyplot as plt
import numpy as np
from sklearn.preprocessing import MinMaxScaler
from sklearn.feature_selection import SelectKBest

from feature_format import featureFormat, targetFeatureSplit
from tester import dump_classifier_and_data

### Task 1: Select what features you'll use.
### features_list is a list of strings, each of which is a feature name.
### The first feature must be "poi".
'''Adding all features to list - will reassign this later after feature selection.'''
features_list = ['poi', 'salary', 'bonus', 'deferral_payments', 'deferred_income', 'director_fees', 'expenses',
				'exercised_stock_options', 'long_term_incentive', 'loan_advances', 'other',
				'restricted_stock', 'restricted_stock_deferred', 'total_payments', 'total_stock_value',
				'from_messages', 'to_messages', 'from_poi_to_this_person', 'from_this_person_to_poi', 'shared_receipt_with_poi',
				'from_poi_ratio', 'to_poi_ratio' ]

### Load the dictionary containing the dataset
with open("final_project_dataset.pkl", "r") as data_file:
    data_dict = pickle.load(data_file)
my_dataset = data_dict
### Task 2: Remove outliers

try:
	del my_dataset['TOTAL']
	del my_dataset['THE TRAVEL AGENCY IN THE PARK']
	#del my_dataset['LAY KENNETH L']
	del my_dataset['FREVERT MARK A']

except KeyError:
    pass


### Task 3: Create new feature(s)
### Store to my_dataset for easy export below.


'''
I'm going to add a from_poi_ratio and to_poi_ration to each person with email data.
'''

def get_ratio(numer_str, denom_str) :
	
	if numer_str == "0" or numer_str == "NaN" :
		return 0.0
	else :
		numer = float(numer_str)	
		
	if denom_str == "0" or denom_str == "NaN" :
		return 0.0
	else :
		denom = float(denom_str)
	
	if denom == 0.0 : 
		#Shouldn't need the above line but keep getting an error without.
		return 0.0
	else :
		return numer/denom

for key, value in my_dataset.iteritems() :
	to_ratio = 0.0
	from_ratio = 0.0

	if value['email_address'] != "NaN" :

		to_ratio = get_ratio(value['to_messages'], value['from_this_person_to_poi'])
		from_ratio = get_ratio(value['from_messages'], value['from_poi_to_this_person'])
		
	value['from_poi_ratio'] = str(from_ratio)
	value['to_poi_ratio'] = str(to_ratio)



### Extract features and labels from dataset for local testing
data = featureFormat(my_dataset, features_list, sort_keys = True)
labels, features = targetFeatureSplit(data)



'''
Print some stats about the dataset
'''
count_people = 0
count_features = 0
max_count_features = 0
epected_count_features = 23
for key, value in my_dataset.iteritems():
	count_features = 0
	count_people += 1
	for k, v in value.iteritems():
		count_features += 1
	if count_features > max_count_features:
		max_count_features = count_features
	if count_features != epected_count_features:
		print "Unexpected feature count."
		'''Above is a bit laborious but confirms all persons have 23 features.'''
		
print "***DATASET STATS***"		
print "Total number of features : ", max_count_features
'''21'''
print "Total count of people : ", count_people		
'''142'''	
print "Total number of data points : ", max_count_features * count_people
'''2982'''
	

'''
Looking at feature_format.py, it appears a 0 is just appended as a 0.  This may 
cause problems when 0 is not the same as no data.

I'm going to count these to try and get an idea on it's impact on accuracy.
'''
count_isnan = 0
count_iszero = 0
for key, value in my_dataset.iteritems():
	for val in value.itervalues():
		if val == 0:
			count_iszero += 1
		elif val == "NaN":
			count_isnan += 1
print "Total count of isnan: ", count_isnan
'''1330'''
print "Total count of iszero: ", count_iszero
'''157'''	
print "***              ***"			


'''
Outlier Exploration.

I'm going to do a number of scatter plots here.  I'm going to change the features list to generate
lists and plot them using matplotlib

features_list = ['poi', 'salary', 'bonus', 'deferral_payments', 'deferred_income', 'director_fees', 'expenses',
				'exercised_stock_options', 'long_term_incentive', 'loan_advances', 'other',
				'restricted_stock', 'restricted_stock_deferred', 'total_payments', 'total_stock_value',
				'from_messages', 'to_messages', 'from_poi_to_this_person', 'from_this_person_to_poi', 'shared_receipt_with_poi' ,
				'from_poi_ratio', 'to_poi_ratio' ]
				
START OUTLIER EXPLORATION
'''

'''
def showScatter(x, y, xlab, ylab) :
	xval = zip(*features)[x]  
	yval = zip(*features)[y]
	
	plt.scatter(xval, yval, c = labels)
	plt.xlabel(xlab)
	plt.ylabel(ylab)
	plt.show()

	
showScatter(0, 1, "salary", "bonus")
showScatter(2, 3, "deferral_payments", "deferred_income")
showScatter(4, 5, "director_fees", "expenses")
showScatter(6, 7, "exercised_stock_options", "long_term_incentive")
showScatter(8, 9, "loan_advances", "other")
showScatter(10, 11, "restricted_stock", "restricted_stock_deferred")
showScatter(12, 13, "total_payments", "total_stock_value")
showScatter(14, 15, "from_messages", "to_messages")
showScatter(16, 17, "from_poi_to_this_person", "from_this_person_to_poi")
showScatter(14, 18, "from_messages", "shared_receipt_with_poi")
showScatter(19, 20, "from_poi_ratio", "to_poi_ration")
'''
	


### Task 4: Try a varity of classifiers
### Please name your classifier clf for easy export below.
### Note that if you want to do PCA or other multi-stage operations,
### you'll need to use Pipelines. For more info:
### http://scikit-learn.org/stable/modules/pipeline.html

# Provided to give you a starting point. Try a variety of classifiers.
'''
I'm going to try a variety of classifiers and pick whichever looks best.
'''

'''
from sklearn.naive_bayes import GaussianNB
clf = GaussianNB()

from sklearn.svm import LinearSVC
clf = LinearSVC()

from sklearn.ensemble import AdaBoostClassifier
clf = AdaBoostClassifier()

from sklearn.ensemble import RandomForestClassifier
clf = RandomForestClassifier()

from sklearn.ensemble import ExtraTreesClassifier
clf = ExtraTreesClassifier()
'''

from sklearn.tree import DecisionTreeClassifier
clf = DecisionTreeClassifier(criterion='entropy',min_samples_split=20,random_state=42)



### Task 5: Tune your classifier to achieve better than .3 precision and recall 
### using our testing script. Check the tester.py script in the final project
### folder for details on the evaluation method, especially the test_classifier
### function. Because of the small size of the dataset, the script uses
### stratified shuffle split cross validation. For more info: 
### http://scikit-learn.org/stable/modules/generated/sklearn.cross_validation.StratifiedShuffleSplit.html





'''
Feature Selection.

I'm going to use SelectKBest to select features.  I'll start with 10 and play around a bit after.
'''
from sklearn.decomposition import PCA

#selector = SelectKBest(k=10)

selector = PCA(n_components='mle',svd_solver='full')
selected_features = selector.fit_transform(features, labels)



'''
Scaler not needed when using decision trees.

scaler = MinMaxScaler()
scaled_selected_features = scaler.fit_transform(selected_features)
'''


'''
Best output seemed to be with k=15, but think that might cause over - fitting. Going
to go with k=10

print (selector.get_support(indices=True))
returns [0, 1, 3, 6, 7, 8, 10, 12, 13, 18]
selected_features =  ['salary', 'bonus', 'deferred_income', 
				'exercised_stock_options', 'long_term_incentive', 'loan_advances', 
				'restricted_stock', 'total_payments', 'total_stock_value',
				'shared_receipt_with_poi']
'''


'''Reassign features list.'''
'''
features_list = ['poi', 'salary', 'bonus', 'deferred_income', 
				'exercised_stock_options', 'long_term_incentive', 'loan_advances', 
				'restricted_stock', 'total_payments', 'total_stock_value',
				'shared_receipt_with_poi']
				'''
				
# Example starting point. Try investigating other evaluation techniques!
from sklearn.cross_validation import train_test_split
features_train, features_test, labels_train, labels_test = \
    train_test_split(selected_features, labels, test_size=0.3, random_state=42)
'''Note to self - keep this constant until algorithm is chosen and tuned.  Use k-fold if time.

edit - tester.py uses StratifiedShuffleSplit with 1000 folds.  I'm not going to take the time
to try to do better.
'''
### Task 6: Dump your classifier, dataset, and features_list so anyone can
### check your results. You do not need to change anything below, but make sure
### that the version of poi_id.py that you submit can be run on its own and
### generates the necessary .pkl files for validating your results.

dump_classifier_and_data(clf, my_dataset, features_list)



'''
Evaluation Scores.

This duplicates some of the work done by tester.py, but is a requirement of the rubic.  
I'll paste in more metrics than I need, but in my final report I'll likely use precision 
and recall.
'''

'''
Before I can evaluate I need to fit and predict.

Going to measure time here too - if these steps take a long time it gives some feedback.
'''
print "*** EVALUATION METRICS***"

t0 = time()

### fit the classifier on the training features and labels
clf.fit(features_train, labels_train)
print "Training time :", round(time()-t0, 3), "s"

### use the trained classifier to predict labels for the test features
t1 = time()
pred = clf.predict(features_test)
print "Predicting time :", round(time()-t1, 3), "s"

'''
Print evaluation metrics.
'''
from sklearn import metrics

acc = metrics.accuracy_score(pred, labels_test)
print "Accuracy score : ", acc

precision = metrics.precision_score(pred, labels_test)
print "Precision score : ", precision

recall = metrics.recall_score(pred, labels_test)
print "Recall score : ", recall

f_one = metrics.f1_score(pred, labels_test)
print "F1 score : ", f_one